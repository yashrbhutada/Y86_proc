

int main() {
    int a = 1; int b = 1; int i = 3; 
    while(i){
        a = a+b;
        b = a+b;
        i--;
    }
    return 0;
}